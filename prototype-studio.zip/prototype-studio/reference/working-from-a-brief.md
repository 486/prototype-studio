# Working from a product brief

Sometimes the input isn't a one-line idea — it's a **product brief**: a document (file, pasted text, or URL) carrying business rules, screen descriptions, API endpoints, data shapes, secrets, and acceptance criteria. The skill's job is unchanged — hand the business user something they can click — but a brief gives you far more to work from. Mine it; don't discard the detail because "the substrate stays invisible." Invisible to *them* in the chat ≠ thrown away. The technical detail belongs **in the project**, not in the conversation.

This file is the depth behind SOP Step 3 (alignment) and Step 4 (build) when the input is a brief.

## 1. Read it fully, then extract
You MUST read the entire brief before asking anything. Then extract, into your working notes and ultimately the project's `CLAUDE.md`, four things:
- **Business rules** — the exact logic the prototype must implement (scoring formulas, what each screen must show, how totals combine). These are non-negotiable; guessing them wrong fails the brief.
- **Services** — every external endpoint, its method, path, query params, and (where shown) request/response shape.
- **Secrets** — any API key, token, or credential printed in the brief.
- **Acceptance criteria** — anything framed as "evaluation," "must," "criteria," or success conditions. These become your Step 4 verification checklist.

## 2. Probe the services to learn real shapes
You SHOULD call the read (`GET`) endpoints the brief names — once, during alignment/setup — to learn the **actual** field names and value formats, rather than guessing. This is how you get believable data instead of inventing fields the API doesn't have. Capture a representative response so seed/mock data mirrors the real shape. You MUST NOT call write/mutating endpoints (`PUT`/`POST`/`DELETE`) just to explore — only when the feature genuinely needs it.

## 3. Grill only the true gaps
A detailed brief answers most questions itself, so per SOP Step 3 you MUST resolve-by-reading first and only grill the genuine ambiguities — one at a time, each with a recommended answer, in plain product language. Typical real gaps in a brief: which screen is the landing view, what happens before the user has made any predictions, how to handle a match that has no result yet. Typical *non*-gaps you MUST NOT ask about: anything the brief states explicitly (scoring values, endpoint URLs, which data each screen shows).

## 4. Secrets — server-side only
A key printed in a shared brief is low-trust and effectively disposable, but you still MUST handle it correctly so it never leaks into shipped client code:
- Store it in a gitignored env file (`.env.local`), read it only in server-side code (server actions, server components, or a server-only lib module).
- You MUST NOT put it in a `NEXT_PUBLIC_*` variable, a client component, the browser bundle, or committed source. You MUST NOT hardcode it inline.
- If a key must be referenced in `CLAUDE.md` for future sessions, record **where it lives** (e.g. "leaderboard API key in `.env.local` as `LEADERBOARD_API_KEY`"), not the key value itself.
- Confirm `.env.local` (and `.env*`) is in `.gitignore` before committing anything.

## 5. Wire external services cleanly
- **One server-side module per concern.** Put all calls to a given service behind a single lib module (e.g. `src/lib/<domain>-api.ts`) with typed functions. Client components call server actions; server actions call the lib; the lib calls the API with the key. The key never crosses to the client.
- **Local DB for user data, live fetch for reference data.** Keep what the user creates (predictions, picks, comments, reactions) in local SQLite via Drizzle so it persists across reloads. Fetch data the brief's services own (match lists, standings, membership totals) live, rather than copying it into the DB where it can go stale.
- **Mind read-then-write endpoints.** If an update endpoint *replaces* a value rather than incrementing it (a common shape: a leaderboard `PUT` that sets the score to the body value), you MUST read the current value and add to it before writing, or you'll clobber accumulated state. Treat any "update" endpoint as replace-by-default unless the brief says otherwise.
- **Derived totals.** When a screen shows a combined number (e.g. "membership points **plus** prediction points"), compute it from its sources at read time rather than storing a stale copy.

## 6. Turn the brief into a verification checklist
Before reporting success (SOP Step 4), you MUST check the build against the acceptance criteria you extracted, not just "it renders and persists." Concretely:
- Each business rule produces the right result on a worked example (e.g. an exact-score prediction scores the higher value, not the sum).
- Combined/derived totals add up from the correct sources.
- A write to an external service actually persists (re-read it and confirm), and accumulates rather than overwrites.
- Every screen the brief names exists and shows what the brief says it shows.
- The app runs in the preview with no console errors.

## 7. Record it in CLAUDE.md
Per the SOP's "Keep CLAUDE.md current" rule, you MUST capture the extracted services (endpoints + how they're wrapped), where secrets live, the business rules, and the acceptance checklist under "What's set up here" — so a future cold session can act correctly without re-reading the original brief.
