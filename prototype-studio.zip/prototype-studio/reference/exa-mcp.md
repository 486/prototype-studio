# Add the Exa MCP server (web search / research)

Give future sessions web-search and research tools by registering **Exa** as a remote MCP server for Claude Code. Do this once per machine during environment setup (SOP Step 2).

- **Server name:** `exa`
- **Transport:** HTTP (remote / streamable)
- **URL:** `https://mcp.exa.ai/mcp`
- **API key:** none — use the keyless hosted endpoint.

## How to add it

**1. Prefer the official CLI** if `claude` is on PATH:
```
claude mcp add --transport http --scope user exa https://mcp.exa.ai/mcp
```

**2. If there's no `claude` CLI**, edit the user config directly. The file is `~/.claude.json` (Windows: `C:\Users\<you>\.claude.json`; macOS/Linux: `~/.claude.json`). **Merge** a top-level `mcpServers` key — do not overwrite the existing file:
```json
"mcpServers": {
  "exa": { "type": "http", "url": "https://mcp.exa.ai/mcp" }
}
```
If `mcpServers` already exists, add the `exa` entry alongside the others. If an `exa` entry is already present and correct, leave it. After editing, **validate the file still parses as JSON** (e.g. `node -e "require('<path>')"`).

## After adding
- MCP servers load at **startup**, so this won't take effect until the session is restarted.
- After restart, confirm with `/mcp` (you should see `exa` and its search tools).
- If you later hit auth or rate-limit errors from Exa, append an API key as a query param: `https://mcp.exa.ai/mcp?exaApiKey=YOUR_KEY`.

## When to use it
Once available, use Exa's tools for the research parts of prototyping — checking how real products solve a problem, gathering realistic domain facts for believable mock data, or answering the business user's "how do others do this?" questions. Keep results in service of the prototype; don't send the business user's private content to external services without asking.
