# Installing Node.js (per OS)

Goal: a current **Node.js LTS** (which bundles **npm**) on the user's **permanent PATH**, so every new terminal finds `node` and `npm`. Always install from the official source (`nodejs.org`). After installing, verify with `node --version` and `npm --version` in a *fresh* shell.

First find the current LTS version/filename programmatically (don't hardcode):
```js
// node available elsewhere, or run via the OS scripting below
fetch('https://nodejs.org/dist/index.json').then(r=>r.json()).then(l=>{
  const lts = l.find(v => v.lts);
  console.log(lts.version); // e.g. v24.16.0
});
```

## Windows
Prefer a no-admin, scriptable install: download the official **zip** and add it to the user PATH. (The `.msi` works too but needs the GUI/admin.)
```powershell
# In PowerShell. Replace <VER> with the LTS version, e.g. v24.16.0
$ver='<VER>'; $dir='C:\Users\<USER>\nodejs'
Invoke-WebRequest "https://nodejs.org/dist/$ver/node-$ver-win-x64.zip" -OutFile "$env:TEMP\node.zip"
Expand-Archive "$env:TEMP\node.zip" "$env:TEMP\node-x" -Force
if (Test-Path $dir) { Remove-Item -Recurse -Force $dir }
Move-Item "$env:TEMP\node-$ver-win-x64" $dir
# Add to PERSISTENT user PATH:
$p=[Environment]::GetEnvironmentVariable('Path','User')
if ($p -notlike "*$dir*") { [Environment]::SetEnvironmentVariable('Path', ($p.TrimEnd(';')+';'+$dir), 'User') }
```
Notes: a sandboxed/standalone `node.exe` may write to a virtualized filesystem invisible to other processes — use a real install dir under the user profile as above. New shells pick up the PATH change; the current one may need its PATH amended for the rest of the session.

## macOS
If Homebrew is present: `brew install node` (current) or `brew install node@<major>` for LTS, then ensure it's linked. Without Homebrew, download the official **.pkg** from `https://nodejs.org/dist/<VER>/node-<VER>.pkg` and install it (it places `node`/`npm` on PATH at `/usr/local/bin`). Apple Silicon and Intel both covered by the universal pkg.

## Linux
Download the official **tarball** and put it on PATH (no sudo needed for a user-local install):
```bash
VER=<VER>   # e.g. v24.16.0
ARCH=x64    # or arm64 on ARM machines
curl -fsSLo /tmp/node.tar.xz "https://nodejs.org/dist/$VER/node-$VER-linux-$ARCH.tar.xz"
mkdir -p "$HOME/.local/node" && tar -xJf /tmp/node.tar.xz -C "$HOME/.local/node" --strip-components=1
# Add to PATH persistently (pick the user's shell rc):
echo 'export PATH="$HOME/.local/node/bin:$PATH"' >> "$HOME/.bashrc"   # and/or ~/.zshrc
export PATH="$HOME/.local/node/bin:$PATH"   # for the current shell
```
Distro package managers (`apt`, `dnf`) often ship outdated Node — prefer the official tarball for a current LTS. NodeSource is an acceptable official-adjacent alternative if a system package is required.

## After installing (all OSes)
- Confirm in a fresh shell: `node --version && npm --version`.
- If a project's `node_modules` was copied from another OS, delete it and run `npm install` again so native binaries match this machine.
