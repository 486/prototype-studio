# Installing Node.js (per OS)

Goal: a current **Node.js LTS** (which bundles **npm**) on the user's **permanent PATH**, so every new terminal finds `node` and `npm`. Always install from the official source (`nodejs.org`). After installing, verify with `node --version` and `npm --version` in a *fresh* shell.

**You MUST determine the current LTS version by querying `nodejs.org` at runtime. You MUST NOT state or assume an LTS version from memory** — the LTS line advances over time (it has been 18, then 20, then 22, then 24, …), and a version recalled from training data is routinely stale. Run one of the commands below and use whatever version it prints; treat the `<VER>` placeholder elsewhere in this file as that value.

The index lists releases newest-first, and the first entry whose `lts` field is truthy is the current LTS line's latest patch:
```bash
# If a node is already on PATH (e.g. you're replacing a broken/old one):
node -e 'fetch("https://nodejs.org/dist/index.json").then(r=>r.json()).then(l=>console.log(l.find(v=>v.lts).version))'

# No node available — POSIX shell (macOS/Linux), via python3 (near-universal there):
curl -fsSL https://nodejs.org/dist/index.json | python3 -c 'import json,sys; print(next(r["version"] for r in json.load(sys.stdin) if r["lts"]))'

# No node available — Windows PowerShell:
# NOTE: filter on `-is [string]`, NOT just `{ $_.lts }`. PowerShell treats every non-empty
# value as truthy, so a bare `{ $_.lts }` keeps EVERY release (the LTS field is a codename
# string like "Jod" for LTS and the boolean $false otherwise). `-is [string]` keeps only LTS.
(Invoke-RestMethod https://nodejs.org/dist/index.json | Where-Object { $_.lts -is [string] } | Select-Object -First 1).version
```
If a command is awkward on the host, the dependable fallback is to open `https://nodejs.org` and read the version on the **"… LTS — Recommended For Most Users"** button. Either way, the version is *looked up*, never guessed.

## Windows
Prefer a no-admin, scriptable install: download the official **zip** and add it to the user PATH. (The `.msi` works too but needs the GUI/admin.) This block **looks up the LTS version itself** (so there's no `<VER>` to substitute by hand) and picks the right CPU arch:
```powershell
# PowerShell — self-contained: fetches current LTS, downloads, installs to the user profile, persists PATH.
# `-is [string]` is required: the LTS field is a codename string for LTS releases and $false
# otherwise; a bare `{ $_.lts }` matches every release (PS treats all non-empty values as truthy).
$ver  = (Invoke-RestMethod https://nodejs.org/dist/index.json | Where-Object { $_.lts -is [string] } | Select-Object -First 1).version
$arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }
$dir  = Join-Path $env:USERPROFILE 'nodejs'
Invoke-WebRequest "https://nodejs.org/dist/$ver/node-$ver-win-$arch.zip" -OutFile "$env:TEMP\node.zip"
Expand-Archive "$env:TEMP\node.zip" "$env:TEMP\node-x" -Force
if (Test-Path $dir) { Remove-Item -Recurse -Force $dir }
Move-Item "$env:TEMP\node-$ver-win-$arch" $dir
# Add to PERSISTENT user PATH:
$p = [Environment]::GetEnvironmentVariable('Path','User')
if ($p -notlike "*$dir*") { [Environment]::SetEnvironmentVariable('Path', ($p.TrimEnd(';')+';'+$dir), 'User') }
# Make it available in THIS session too:
$env:Path = "$dir;$env:Path"
node --version; npm --version
```
**Where this puts Node (important for the same session).** The block installs to `%USERPROFILE%\nodejs`, so the binaries are at:
- `%USERPROFILE%\nodejs\node.exe`
- `%USERPROFILE%\nodejs\npm.cmd` (and `npx.cmd`)

The PATH edit above is **persistent (new shells only)**. A shell already open — including the one you're running commands in right now, and any separate command invocations that don't inherit the in-session `$env:Path` line — will **not** see Node on PATH yet, so a bare `node --version` can fail *even though Node is installed*. You MUST NOT read that failure as "Node missing" and reinstall. Instead, until a fresh shell is in use, either:
- invoke Node by its **full path**, e.g. `& "$env:USERPROFILE\nodejs\node.exe" --version` (and `& "$env:USERPROFILE\nodejs\npm.cmd" install`), or
- prepend it to PATH for the current session first: `$env:Path = "$env:USERPROFILE\nodejs;$env:Path"`, then call `node`/`npm` normally.

Notes: a sandboxed/standalone `node.exe` may write to a virtualized filesystem invisible to other processes — use a real install dir under the user profile as above.

## macOS
If Homebrew is present: `brew install node` (current) or `brew install node@<major>` for LTS, then ensure it's linked. Without Homebrew, download the official **.pkg** from `https://nodejs.org/dist/<VER>/node-<VER>.pkg` and install it (it places `node`/`npm` on PATH at `/usr/local/bin`). Apple Silicon and Intel both covered by the universal pkg.

## Linux
Download the official **tarball** and put it on PATH (no sudo needed for a user-local install):
```bash
VER=<VER>   # e.g. v24.16.0
ARCH=x64    # or arm64 on ARM machines
curl -fsSLo /tmp/node.tar.xz "https://nodejs.org/dist/$VER/node-$VER-linux-$ARCH.tar.xz"
mkdir -p "$HOME/.local/node" && tar -xJf /tmp/node.tar.xz -C "$HOME/.local/node" --strip-components=1
# Add to PATH persistently (pick the user's shell rc):
echo 'export PATH="$HOME/.local/node/bin:$PATH"' >> "$HOME/.bashrc"   # and/or ~/.zshrc
export PATH="$HOME/.local/node/bin:$PATH"   # for the current shell
```
Distro package managers (`apt`, `dnf`) often ship outdated Node — prefer the official tarball for a current LTS. NodeSource is an acceptable official-adjacent alternative if a system package is required.

## After installing (all OSes)
- **Refresh PATH in the *current* session before re-checking** — don't wait for a new shell, and don't misread a not-found as "install failed." Each install block above already prepends to the session PATH; if you're in a *separate* command invocation, do it again first:
  - macOS/Linux: `export PATH="$HOME/.local/node/bin:$PATH"` (Homebrew installs are already on PATH).
  - Windows PowerShell: `$env:Path = "$env:USERPROFILE\nodejs;$env:Path"`.
  Then confirm: `node --version && npm --version` (PowerShell: `node --version; npm --version`).
- If a command runner spawns a fresh process per call (so the session `$env:Path` doesn't carry over), invoke Node/npm by **full path** instead — see the Windows paths above (`%USERPROFILE%\nodejs\node.exe`, `npm.cmd`).
- If a project's `node_modules` was copied from another OS, delete it and run `npm install` again so native binaries match this machine.
