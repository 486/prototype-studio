# Environment Contract (Step 2 details)

The full rules behind "make sure the environment is ready" (SOP Step 2). You MUST apply these silently; the business user MUST see outcomes, not mechanics.

## Install latitude
- **You MAY install, without asking:** Node.js + npm and any developer tooling/build dependencies, **from official vendor sites only** (nodejs.org, the npm registry, official OS package managers). You MUST add such tools to the user's permanent PATH.
- **You MUST ask first, every time, before:** spending money; signing into or creating accounts; publishing or sending anything; changing security, sharing, or system settings; deleting files the business user created. If a step needs a decision only they can make, You MUST ask one plain-language question.
- You MUST NOT install from random mirrors or untrusted sources.

## Diagnosing common breakages
You MUST resolve these yourself rather than surfacing them to the business user:
- **`node_modules` exists but commands fail** (e.g. "cannot find module … -win32-/-linux-", missing `.node` binary): it was copied from another machine/OS. You MUST delete `node_modules` and any lockfile mismatch, then `npm install` fresh on this machine.
- **No `node`/`npm` on PATH:** You MUST install Node (bundles npm) per `install-node.md`, persist PATH, and verify in a fresh shell.
- **A standalone/sandboxed `node` writes files no other process can see:** it has a virtualized filesystem. You MUST do a real install to a user-profile directory instead, and run package-manager commands through that.
- **Native module won't load** (the SQLite driver): You MUST ensure it was installed on *this* machine (`npm install` here), not copied in.
- **Preview won't start:** You MUST check `.claude/launch.json` has the correct run command and port, and that `npm install` completed, before anything else.
- **Port already in use:** the starter's `.claude/launch.json` sets `"autoPort": true`, so the preview falls back to a free port on its own — no edit needed. You MUST NOT reintroduce a hardcoded `-p 3000` in the dev script (it uses plain `next dev`, honoring the assigned `PORT`); doing so prevents autoPort from taking effect.
- **Preview can't find `launch.json` (scaffolded into a subfolder):** `Claude_Preview` resolves `.claude/launch.json` from the *session's working directory*, not the project subfolder. You SHOULD prefer opening the project folder itself as the workspace. When you can't change cwd, You MAY drop a shim copy at the session cwd with `runtimeArgs: ["--prefix", "<subfolder>", "run", "dev"]` and `"autoPort": true`. The project's own `.claude/launch.json` remains canonical; You SHOULD remove the shim once the project is opened directly.

## OS notes
- **Windows:** You SHOULD prefer the official Node zip + user-PATH (no admin) over the MSI, and use a real directory under the user profile. Forward slashes work in Node; in shell prefer the platform default.
- **macOS:** You SHOULD use Homebrew `node` if present, else the official `.pkg`.
- **Linux:** You SHOULD use the official tarball to `~/.local/node` + PATH in the shell rc, and avoid stale distro packages.

You SHOULD read `install-node.md` for exact commands.

## Verify before reporting success
You MUST NOT stop at "the server started." The proof is **persistence through the preview**: You MUST add an item via the app's UI, reload, and confirm it's still there. If that fails, the database/native layer is wrong — You MUST fix it before telling the business user they're ready.

## What to report to the business user
When setup is done, You MUST report:
- One sentence: ready, and that you'll show prototypes in the integrated preview where they can click and draw on them.
- A short bullet list of what you installed and where (so their IT has a record).
- How to start the app next time (one line).
- One example sentence they could say to start building (e.g. *"Add a page where I can track customer feedback with a title, a priority, and who owns it."*).
