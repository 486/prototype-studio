# Environment Contract (Step 1 details)

The full rules behind "make sure the environment is ready." Apply these silently; the leader
should see outcomes, not mechanics.

## Install latitude
- **You may install, without asking:** Node.js + npm and any developer tooling/build
  dependencies, **from official vendor sites only** (nodejs.org, the npm registry, official OS
  package managers). Add tools to the user's permanent PATH.
- **Ask first, every time:** spending money; signing into or creating accounts; publishing or
  sending anything; changing security, sharing, or system settings; deleting files the leader
  created. If a step needs a decision only they can make, ask one plain-language question.
- **Never** install from random mirrors or untrusted sources.

## Diagnosing common breakages
- **`node_modules` exists but commands fail** (e.g. "cannot find module … -win32-/-linux-",
  missing `.node` binary): it was copied from another machine/OS. Delete `node_modules` and any
  lockfile mismatch, then `npm install` fresh on this machine.
- **No `node`/`npm` on PATH:** install Node (bundles npm) per `install-node.md`, persist PATH,
  verify in a fresh shell.
- **A standalone/sandboxed `node` writes files no other process can see:** it has a virtualized
  filesystem. Do a real install to a user-profile directory instead, and run package-manager
  commands through that.
- **Native module won't load** (the SQLite driver): ensure it was installed on *this* machine
  (`npm install` here), not copied in.
- **Preview won't start:** check `.claude/launch.json` has the correct run command and port,
  and that `npm install` completed, before anything else.
- **Port already in use:** the starter's `.claude/launch.json` sets `"autoPort": true`, so the
  preview falls back to a free port on its own — no edit needed. (The dev script uses plain
  `next dev`, honoring the assigned `PORT`; don't reintroduce a hardcoded `-p 3000`, or autoPort
  can't take effect.)
- **Preview can't find `launch.json` (scaffolded into a subfolder):** `Claude_Preview` resolves
  `.claude/launch.json` from the *session's working directory*, not the project subfolder.
  Preferred fix: open the project folder itself as the workspace. Fallback when you can't change
  cwd: drop a shim copy at the session cwd with `runtimeArgs: ["--prefix", "<subfolder>", "run",
  "dev"]` and `"autoPort": true`. The project's own `.claude/launch.json` remains canonical;
  remove the shim once the project is opened directly.

## OS notes
- **Windows:** prefer the official Node zip + user-PATH (no admin) over the MSI. Use a real
  directory under the user profile. Forward slashes work in Node; in shell prefer the platform
  default.
- **macOS:** Homebrew `node` if present, else the official `.pkg`.
- **Linux:** official tarball to `~/.local/node` + PATH in the shell rc; avoid stale distro
  packages.
See `install-node.md` for exact commands.

## Verify before reporting success
Never stop at "the server started." The proof is **persistence through the preview**: add an
item via the app's UI, reload, confirm it's still there. If that fails, the database/native
layer is wrong — fix it before telling the leader they're ready.

## What to report to the leader
- One sentence: ready, and that you'll show prototypes in the integrated preview where they can
  click and draw on them.
- A short bullet list of what you installed and where (so their IT has a record).
- How to start the app next time (one line).
- One example sentence they could say to start building (e.g. *"Add a page where I can track
  customer feedback with a title, a priority, and who owns it."*).
