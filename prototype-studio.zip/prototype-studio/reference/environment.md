# Environment Contract (Step 2 details)

The full rules behind "make sure the environment is ready" (SOP Step 2). You MUST apply these silently; the business user MUST see outcomes, not mechanics.

## Install latitude
- **You MAY install, without asking:** Node.js + npm and any developer tooling/build dependencies, **from official vendor sites only** (nodejs.org, the npm registry, official OS package managers). You MUST add such tools to the user's permanent PATH.
- **You MUST ask first, every time, before:** spending money; signing into or creating accounts; publishing or sending anything; changing security, sharing, or system settings; deleting files the business user created. If a step needs a decision only they can make, You MUST ask one plain-language question.
- You MUST NOT install from random mirrors or untrusted sources.

## Diagnosing common breakages
You MUST resolve these yourself rather than surfacing them to the business user:
- **`node_modules` exists but commands fail** (e.g. "cannot find module … -win32-/-linux-", missing `.node` binary): it was copied from another machine/OS. You MUST delete `node_modules` and any lockfile mismatch, then `npm install` fresh on this machine.
- **No `node`/`npm` on PATH:** You MUST install Node (bundles npm) per `install-node.md`, persist PATH, and verify in a fresh shell.
- **A standalone/sandboxed `node` writes files no other process can see:** it has a virtualized filesystem. You MUST do a real install to a user-profile directory instead, and run package-manager commands through that.
- **Native module won't load** (the SQLite driver): You MUST ensure it was installed on *this* machine (`npm install` here), not copied in.
- **Preview won't start:** You MUST check `.claude/launch.json` has the correct run command and port, and that `npm install` completed, before anything else.
- **Port already in use:** the starter's `.claude/launch.json` sets `"autoPort": true`, so the preview falls back to a free port on its own — no edit needed. You MUST NOT reintroduce a hardcoded `-p 3000` in the dev script (it uses plain `next dev`, honoring the assigned `PORT`); doing so prevents autoPort from taking effect.
- **Preview can't find `launch.json` (scaffolded into a subfolder):** `Claude_Preview` resolves `.claude/launch.json` from the *session's working directory*, not the project subfolder. You SHOULD prefer opening the project folder itself as the workspace. When you can't change cwd, You MAY drop a shim copy at the session cwd:
  - macOS/Linux: `runtimeExecutable: "npm"`, `runtimeArgs: ["--prefix", "<subfolder>", "run", "dev"]`, `"autoPort": true`.
  - Windows: the `--prefix` form usually fails because the preview spawns the dev process without the shell PATH (so even `npm.cmd` can't find `node`). Use `cmd.exe` and set PATH + `cd` inline with the full Node dir instead: `runtimeExecutable: "C:\\Windows\\System32\\cmd.exe"`, `runtimeArgs: ["/c", "set PATH=%USERPROFILE%\\nodejs;%PATH% && cd <subfolder> && npm run dev"]`, `"autoPort": true`.
  The project's own `.claude/launch.json` remains canonical; You SHOULD remove the shim once the project is opened directly.
- **Preview starts on macOS/Linux but not Windows when opened directly (PATH not inherited):** the preview subprocess may not inherit the shell PATH on Windows, so a plain `runtimeExecutable: "npm"` can't find `node`. The remedy is the same `cmd.exe` + inline `set PATH=%USERPROFILE%\nodejs;%PATH%` form shown above (without the `cd` if already at the project root). See "Hardening the canonical launch.json for Windows" below.

## OS notes
- **Windows:** You SHOULD prefer the official Node zip + user-PATH (no admin) over the MSI, and use a real directory under the user profile. Forward slashes work in Node; in shell prefer the platform default.
- **macOS:** You SHOULD use Homebrew `node` if present, else the official `.pkg`.
- **Linux:** You SHOULD use the official tarball to `~/.local/node` + PATH in the shell rc, and avoid stale distro packages.

You SHOULD read `install-node.md` for exact commands.

## Hardening the canonical launch.json for Windows
The starter template ships `.claude/launch.json` with `runtimeExecutable: "npm"`, which is correct on macOS/Linux. On Windows the preview subprocess may not inherit the shell PATH, so `npm` can't find `node` and the preview never starts. `scaffold.mjs` therefore **rewrites the scaffolded `launch.json` on Windows** to launch via `cmd.exe` with the real Node directory prepended to PATH — deriving that directory from the scaffolding Node's own `process.execPath` (more reliable than assuming `%USERPROFILE%\nodejs`). If you ever hand-edit `launch.json` on Windows, preserve that form:
```json
{ "runtimeExecutable": "C:\\Windows\\System32\\cmd.exe",
  "runtimeArgs": ["/c", "set PATH=<node-dir>;%PATH% && npm run dev"],
  "port": 3000, "autoPort": true }
```

## Probing setup state
`node scripts/status.mjs <target-folder>` prints machine-readable JSON describing whether the environment is ready and, if not, exactly what's missing — `node_modules`, `CLAUDE.md`, `sqlite.db`, `drizzle` migrations, `.claude/launch.json` — plus a `next` action (`install-node` / `scaffold` / `finish-setup` / `build`) and the current Node LTS vs. the running version. Use it to skip the slow scaffold/install when setup is already done (a `build`-mode run on an existing project) and to know what's left in `setup` mode. `node scripts/doctor.mjs` covers the toolchain (Node + npm presence) and also prints the current LTS; both look the LTS version up at runtime so guidance never depends on a guessed version.

**Windows exit code:** trust the JSON `ok` field, not the process exit code. Some Node builds trip a libuv async-cleanup assertion at teardown and return exit 127 even when the probe succeeded and printed correct JSON. The script sets `process.exitCode` (rather than forcing `process.exit`) to reduce this; if it still happens, parse the output or append `|| true`.

## Verify before reporting success
You MUST NOT stop at "the server started." The proof is **persistence through the preview**: You MUST add an item via the app's UI, reload, and confirm it's still there. If that fails, the database/native layer is wrong — You MUST fix it before telling the business user they're ready.

## What to report to the business user
When setup is done, You MUST report:
- One sentence: ready, and that you'll show prototypes in the integrated preview where they can click and draw on them.
- A short bullet list of what you installed and where (so their IT has a record).
- How to start the app next time (one line).
- One example sentence they could say to start building (e.g. *"Add a page where I can track customer feedback with a title, a priority, and who owns it."*).
