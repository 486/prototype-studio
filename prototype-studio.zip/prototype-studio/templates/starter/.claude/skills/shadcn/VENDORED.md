# Vendored skill — shadcn/ui

These files are a **copy** of the official shadcn skill, vendored into this project so any
session opened here can build UI with shadcn/ui without fetching anything.

- **Source:** https://github.com/shadcn-ui/ui/tree/main/skills/shadcn
- **Vendored on:** 2026-06-10 (from `main`)
- **What's included:** `SKILL.md`, `cli.md`, `mcp.md`, `registry.md`, `customization.md`,
  and `rules/`. The upstream `evals/`, `agents/`, and binary `assets/` are intentionally
  omitted — they aren't needed to build UI in this repo.

## Refreshing

To pull the latest version of the skill:

```bash
BASE="https://raw.githubusercontent.com/shadcn-ui/ui/main/skills/shadcn"
for f in SKILL.md cli.md mcp.md registry.md customization.md; do
  curl -fsS "$BASE/$f" -o ".claude/skills/shadcn/$f"
done
for f in base-vs-radix.md composition.md forms.md icons.md styling.md; do
  curl -fsS "$BASE/rules/$f" -o ".claude/skills/shadcn/rules/$f"
done
```

Then re-add this note (it isn't part of the upstream skill).
