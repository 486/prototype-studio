import { db } from "./index";
import { items } from "./schema";

// Seed a few realistic example rows (never "Item 1, Item 2"). Idempotent: only seeds when
// the table is empty, so re-running setup won't duplicate.
const existing = await db.select().from(items);
if (existing.length === 0) {
  await db.insert(items).values([
    { title: "Onboarding feels too long", note: "Three new customers mentioned it this week." },
    { title: "Add CSV export to reports", note: "Requested by the finance team at Northwind." },
    { title: "Dark mode for the dashboard", note: "Popular ask in the last user interviews." },
  ]);
  console.log("Seeded 3 example items.");
} else {
  console.log(`Skipped seeding — ${existing.length} item(s) already present.`);
}
process.exit(0);
