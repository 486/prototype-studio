import { sql } from "drizzle-orm";
import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

// The starter's single demo model. Replace/extend this with the business user's real data models
// as the prototype grows — then add a migration (npm run db:generate && npm run db:migrate).
export const items = sqliteTable("items", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  note: text("note"),
  createdAt: text("created_at")
    .notNull()
    .default(sql`(current_timestamp)`),
});

export type Item = typeof items.$inferSelect;
export type NewItem = typeof items.$inferInsert;
