import { createClient } from "@libsql/client";
import { drizzle } from "drizzle-orm/libsql";
import * as schema from "./schema";

// Single local SQLite file in the project root. Copy this file = copy the data.
// @libsql/client ships prebuilt binaries — no compiler/Python needed on any machine.
const client = createClient({ url: "file:sqlite.db" });

export const db = drizzle(client, { schema });
export { schema };
