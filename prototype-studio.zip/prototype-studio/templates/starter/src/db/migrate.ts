import { createClient } from "@libsql/client";
import { drizzle } from "drizzle-orm/libsql";
import { migrate } from "drizzle-orm/libsql/migrator";

// Applies any pending migrations in ./drizzle to the local SQLite file.
const client = createClient({ url: "file:sqlite.db" });
const db = drizzle(client);
await migrate(db, { migrationsFolder: "./drizzle" });
console.log("Migrations applied.");
