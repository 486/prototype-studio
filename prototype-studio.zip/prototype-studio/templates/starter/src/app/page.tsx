import { desc } from "drizzle-orm";
import { db } from "@/db";
import { items } from "@/db/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import AddItemForm from "./AddItemForm";

// Server component: reads straight from SQLite on each request, so anything added
// through the form is still here after a reload — that's the persistence proof.
export const dynamic = "force-dynamic";

export default async function Home() {
  const rows = await db.select().from(items).orderBy(desc(items.id));

  return (
    <main className="mx-auto flex max-w-2xl flex-col gap-7 px-6 py-12">
      <div className="flex flex-col gap-1">
        <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Prototype Starter
        </span>
        <h1 className="text-2xl font-semibold tracking-tight">Items</h1>
        <p className="text-muted-foreground">
          A clickable, data-backed starting point built with shadcn/ui. Add something, then
          reload — it persists in a local database.
        </p>
      </div>

      <AddItemForm />

      <div className="flex flex-col gap-3">
        <span className="text-sm text-muted-foreground">
          {rows.length} item{rows.length !== 1 ? "s" : ""}
        </span>

        {rows.length === 0 ? (
          <Card>
            <CardContent className="py-10 text-center text-muted-foreground">
              Nothing yet. Add your first item above.
            </CardContent>
          </Card>
        ) : (
          <div className="flex flex-col gap-3">
            {rows.map((it) => (
              <Card key={it.id}>
                <CardHeader>
                  <CardTitle>{it.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col gap-1 text-sm">
                  {it.note && <p className="text-muted-foreground">{it.note}</p>}
                  <p className="text-xs text-muted-foreground">Added {it.createdAt}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
