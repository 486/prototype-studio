"use client";

import { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { addItem } from "./actions";

// Client form that calls the server action, then clears itself for the next entry.
export default function AddItemForm() {
  const formRef = useRef<HTMLFormElement>(null);
  return (
    <form
      ref={formRef}
      className="flex gap-2"
      action={async (formData) => {
        await addItem(formData);
        formRef.current?.reset();
      }}
    >
      <Input name="title" placeholder="Add an item…" aria-label="Item title" required />
      <Button type="submit">Add</Button>
    </form>
  );
}
