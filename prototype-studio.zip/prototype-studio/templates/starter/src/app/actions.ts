"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { items } from "@/db/schema";

// Server action: persist a new item to SQLite, then refresh the page data.
export async function addItem(formData: FormData) {
  const title = String(formData.get("title") || "").trim();
  const note = String(formData.get("note") || "").trim();
  if (!title) return;
  await db.insert(items).values({ title, note: note || null });
  revalidatePath("/");
}
