import { defineConfig } from "drizzle-kit";

// `generate` only reads the schema to emit SQL migrations — no DB connection needed.
// Migrations are applied programmatically in src/db/migrate.ts via the libsql driver.
export default defineConfig({
  dialect: "sqlite",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
});
