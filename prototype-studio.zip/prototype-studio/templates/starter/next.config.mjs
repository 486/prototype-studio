/** @type {import('next').NextConfig} */
const nextConfig = {
  // Keep the libsql client out of the bundler so its platform binary loads at runtime.
  serverExternalPackages: ["@libsql/client", "libsql"],
};

export default nextConfig;
