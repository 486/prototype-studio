#!/usr/bin/env node
// Environment doctor for prototype-studio. Dependency-free, cross-platform.
// Reports whether Node + npm are present and usable. Exits 0 if ready, 1 if not.
// Run: node scripts/doctor.mjs   (if `node` is missing entirely, see reference/install-node.md)

import { execFileSync } from "node:child_process";
import { platform, arch, release } from "node:os";

function tryCmd(cmd, args) {
  // npm/npx are .cmd shims on Windows; only the shell resolves them via PATH + PATHEXT.
  try {
    const out = execFileSync(cmd, args, {
      encoding: "utf8",
      stdio: ["ignore", "pipe", "ignore"],
      shell: process.platform === "win32",
    });
    return out.trim();
  } catch {
    return null;
  }
}

const report = { os: `${platform()} ${arch()} (${release()})`, checks: [] };
const add = (name, ok, detail) => report.checks.push({ name, ok, detail });

// Node is implied (this script runs under it), but report its version.
add("node", true, process.version);

const npmV = tryCmd("npm", ["--version"]);
add("npm", !!npmV, npmV || "not found on PATH");

const ready = report.checks.every((c) => c.ok);

console.log(`\nprototype-studio doctor — ${report.os}`);
for (const c of report.checks) {
  console.log(`  ${c.ok ? "OK " : "!! "} ${c.name.padEnd(6)} ${c.detail}`);
}
if (ready) {
  console.log("\nReady. Next: node scripts/scaffold.mjs <target-folder>\n");
} else {
  console.log("\nNot ready. Install the missing tool(s) — see reference/install-node.md — then re-run.\n");
}
process.exit(ready ? 0 : 1);
