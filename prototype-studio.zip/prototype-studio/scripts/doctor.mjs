#!/usr/bin/env node
// Environment doctor for prototype-studio. Dependency-free, cross-platform.
// Reports whether npm is present/usable and the current Node LTS. Exits 0 if ready, 1 if not.
//
// REQUIRES NODE: this is a Node program, so it only runs once Node exists. To check whether
// Node itself is installed, use a plain shell `node --version` first — not this script. If
// Node is missing entirely, install it per reference/install-node.md (Node-free), then run this.

import { execFileSync } from "node:child_process";
import { platform, arch, release } from "node:os";

function tryCmd(cmd, args) {
  // npm/npx are .cmd shims on Windows; only the shell resolves them via PATH + PATHEXT.
  try {
    const out = execFileSync(cmd, args, {
      encoding: "utf8",
      stdio: ["ignore", "pipe", "ignore"],
      shell: process.platform === "win32",
    });
    return out.trim();
  } catch {
    return null;
  }
}

const report = { os: `${platform()} ${arch()} (${release()})`, checks: [] };
const add = (name, ok, detail) => report.checks.push({ name, ok, detail });

// Node is implied (this script runs under it), but report its version.
add("node", true, process.version);

const npmV = tryCmd("npm", ["--version"]);
add("npm", !!npmV, npmV || "not found on PATH");

// Current LTS, looked up at runtime so guidance never relies on a stale guessed version.
// Best-effort: silent if offline. Does not affect readiness.
let ltsNote = null;
try {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 4000);
  const res = await fetch("https://nodejs.org/dist/index.json", { signal: ctrl.signal });
  clearTimeout(t);
  if (res.ok) {
    const lts = (await res.json()).find((r) => r.lts); // newest-first; first LTS entry
    if (lts) ltsNote = lts.version;
  }
} catch {
  /* offline or blocked — skip */
}

const ready = report.checks.every((c) => c.ok);

console.log(`\nprototype-studio doctor — ${report.os}`);
for (const c of report.checks) {
  console.log(`  ${c.ok ? "OK " : "!! "} ${c.name.padEnd(6)} ${c.detail}`);
}
if (ltsNote) {
  const runningMajor = Number(/^v?(\d+)/.exec(process.version)?.[1]);
  const ltsMajor = Number(/^v?(\d+)/.exec(ltsNote)?.[1]);
  const stale = Number.isFinite(runningMajor) && Number.isFinite(ltsMajor) && runningMajor < ltsMajor;
  console.log(`     current Node LTS: ${ltsNote}${stale ? ` (running ${process.version} is older — install ${ltsNote} when setting up)` : ""}`);
}
if (ready) {
  console.log("\nReady. Next: node scripts/scaffold.mjs <target-folder>\n");
} else {
  console.log("\nNot ready. Install the missing tool(s) — see reference/install-node.md — then re-run.\n");
}
process.exit(ready ? 0 : 1);
