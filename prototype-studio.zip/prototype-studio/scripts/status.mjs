#!/usr/bin/env node
// Setup-state probe for prototype-studio. Dependency-free, cross-platform (incl. Windows).
// Prints machine-readable JSON: is the environment ready, and if not, what's missing.
// Lets a `build`-mode run skip the slow scaffold/install when it's already done, and tells
// a `setup`-mode run exactly what's left.
//
// REQUIRES NODE: this is a Node program. It can't run before Node is installed — which is fine,
// because every project-state check here (node_modules, migrations, …) only matters AFTER Node
// exists. To detect a missing Node, use a plain shell `node --version` first; see
// reference/install-node.md for the Node-free install path.
//
// Usage:
//   node scripts/status.mjs <target-folder>   # full project + toolchain report
//   node scripts/status.mjs                    # toolchain only (no project checked)
//
// Exit code: 0 if ready (project given and all checks pass), 1 otherwise.
// Always prints JSON to stdout regardless of exit code.

import { existsSync, readdirSync, statSync } from "node:fs";
import { join, resolve, basename } from "node:path";
import { execFileSync } from "node:child_process";

const arg = process.argv.slice(2).find((a) => !a.startsWith("--"));
const target = arg ? resolve(arg) : null;

// --- toolchain ---------------------------------------------------------------
function npmVersion() {
  try {
    // npm is a .cmd shim on Windows; only the shell resolves it via PATH + PATHEXT.
    return execFileSync("npm", ["--version"], {
      encoding: "utf8",
      stdio: ["ignore", "pipe", "ignore"],
      shell: process.platform === "win32",
    }).trim();
  } catch {
    return null;
  }
}

// Current Node LTS, looked up at runtime so it's never a stale guess. Best-effort:
// returns null (not an error) when offline, so the probe still works without network.
async function currentLts() {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 4000);
    const res = await fetch("https://nodejs.org/dist/index.json", { signal: ctrl.signal });
    clearTimeout(t);
    if (!res.ok) return null;
    const list = await res.json();
    const lts = list.find((r) => r.lts); // newest-first; first LTS entry is the current line
    return lts ? lts.version : null;
  } catch {
    return null;
  }
}

const major = (v) => (v && /^v?(\d+)/.exec(v) ? Number(/^v?(\d+)/.exec(v)[1]) : null);

// --- project state -----------------------------------------------------------
// Mirrors what scaffold.mjs produces: deps installed for THIS machine, a CLAUDE.md,
// the SQLite file, applied migrations, and the preview launch config.
function nonEmptyDir(p) {
  try {
    return statSync(p).isDirectory() && readdirSync(p).length > 0;
  } catch {
    return false;
  }
}
function fileExists(p) {
  try {
    return statSync(p).isFile();
  } catch {
    return false;
  }
}

const npmV = npmVersion();
const lts = await currentLts();

const node = {
  running: process.version,
  lts, // may be null if offline — then satisfiesLts is also null (unknown)
  satisfiesLts: lts == null ? null : major(process.version) >= major(lts),
};

const report = {
  ok: false,
  target,
  node,
  npm: npmV,
  checks: {},
  missing: [],
  next: null,
};

if (!target) {
  // Toolchain-only mode: report node/npm/lts, no project verdict.
  report.checks = { npm: !!npmV };
  if (!npmV) report.missing.push("npm");
  report.next = npmV ? "give a <target-folder> to check project state" : "install-node";
  console.log(JSON.stringify(report, null, 2));
  process.exit(npmV ? 0 : 1);
}

const checks = {
  npm: !!npmV,
  projectFolder: existsSync(target) && nonEmptyDir(target),
  nodeModules: nonEmptyDir(join(target, "node_modules")),
  claudeMd: fileExists(join(target, "CLAUDE.md")),
  sqliteDb: fileExists(join(target, "sqlite.db")),
  migrations: nonEmptyDir(join(target, "drizzle")),
  launchJson: fileExists(join(target, ".claude", "launch.json")),
};
report.checks = checks;
report.missing = Object.entries(checks)
  .filter(([, ok]) => !ok)
  .map(([k]) => k);
report.ok = report.missing.length === 0;

// Suggest the next action the SOP should take.
if (!checks.npm) report.next = "install-node";
else if (!checks.projectFolder || !checks.nodeModules) report.next = "scaffold";
else report.next = report.ok ? "build" : "finish-setup"; // e.g. write CLAUDE.md / run db:setup

report.targetName = target ? basename(target) : null;
console.log(JSON.stringify(report, null, 2));
process.exit(report.ok ? 0 : 1);
