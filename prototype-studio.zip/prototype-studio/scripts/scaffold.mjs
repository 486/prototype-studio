#!/usr/bin/env node
// Scaffold a Next.js + Drizzle + SQLite starter from templates/starter.
// Cross-platform, dependency-free. Idempotent-ish: refuses to clobber a non-empty target
// unless --force is passed. Prints what it did.
//
// Usage: node scripts/scaffold.mjs <target-folder> [--force]

import { cpSync, existsSync, mkdirSync, readdirSync, renameSync, writeFileSync } from "node:fs";
import { join, dirname, resolve, basename } from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync, execSync } from "node:child_process";

const __dirname = dirname(fileURLToPath(import.meta.url));
const skillRoot = resolve(__dirname, "..");
const templateDir = join(skillRoot, "templates", "starter");

const args = process.argv.slice(2);
const force = args.includes("--force");
const target = resolve(args.find((a) => !a.startsWith("--")) || "prototype-starter");

function run(cmd, cmdArgs, cwd) {
  const line = `${cmd} ${cmdArgs.join(" ")}`;
  console.log(`  $ ${line}`);
  if (process.platform === "win32") {
    // npm/npx are .cmd shims; only the shell resolves them. Pass one string (not an args
    // array with shell:true) to avoid the DEP0190 deprecation warning.
    execSync(line, { cwd, stdio: "inherit" });
  } else {
    execFileSync(cmd, cmdArgs, { cwd, stdio: "inherit" });
  }
}

console.log(`\nprototype-studio scaffold`);
console.log(`  template: ${templateDir}`);
console.log(`  target:   ${target}`);

if (!existsSync(templateDir)) {
  console.error(`\n!! template not found at ${templateDir}`);
  process.exit(1);
}
if (existsSync(target) && readdirSync(target).length > 0 && !force) {
  console.error(`\n!! target ${target} is not empty. Pass --force to overlay the template anyway.`);
  process.exit(1);
}

mkdirSync(target, { recursive: true });
// Copy template (everything except node_modules / the sqlite db, which are generated fresh).
cpSync(templateDir, target, {
  recursive: true,
  filter: (src) => !/[\\/](node_modules|sqlite\.db|drizzle)$/.test(src),
});

// npm ignores files literally named .gitignore in published templates; ship it as
// gitignore.template and rename on scaffold so the project gets a real one.
const gi = join(target, "gitignore.template");
if (existsSync(gi)) renameSync(gi, join(target, ".gitignore"));

// On Windows, the preview subprocess often does NOT inherit the shell PATH, so the template's
// plain `runtimeExecutable: "npm"` can't find `node` and the preview won't start. Rewrite the
// scaffolded launch.json to launch via cmd.exe with the real Node dir on PATH. We know the dir
// from THIS Node's own location (process.execPath) — more reliable than assuming %USERPROFILE%.
if (process.platform === "win32") {
  const launchPath = join(target, ".claude", "launch.json");
  if (existsSync(launchPath)) {
    const nodeDir = dirname(process.execPath); // e.g. C:\Users\<you>\nodejs
    const launch = {
      version: "0.0.1",
      configurations: [
        {
          name: "prototype",
          runtimeExecutable: "C:\\Windows\\System32\\cmd.exe",
          runtimeArgs: ["/c", `set PATH=${nodeDir};%PATH% && npm run dev`],
          port: 3000,
          autoPort: true,
        },
      ],
    };
    writeFileSync(launchPath, JSON.stringify(launch, null, 2) + "\n");
    console.log(`  patched .claude/launch.json for Windows PATH (node dir: ${nodeDir})`);
  }
}

console.log(`\n  installing dependencies (fresh for this machine)…`);
run("npm", ["install"], target);

console.log(`\n  setting up the database (generate + migrate + seed)…`);
run("npm", ["run", "db:setup"], target);

console.log(`\nDone. Starter app ready at: ${target}`);
console.log(`Next:`);
console.log(`  1. Write CLAUDE.md into ${basename(target)} from reference/CLAUDE.md.template (fill placeholders).`);
console.log(`  2. Start it with the Claude_Preview tools (uses .claude/launch.json), screenshot, then`);
console.log(`     test persistence: add an item in the UI, reload, confirm it survived.\n`);
