---
name: prototype-studio
description: Set up a local environment and build clickable, data-backed web prototypes WITH a non-technical business user. Use when someone wants to turn a product idea into something they can click through and show people, or asks to "build a prototype", "set up a prototyping environment", "make a mockup I can click", or starts describing an app idea in plain language. Installs the stack if missing (Next.js + Drizzle + SQLite), scaffolds a starter app, then builds up from it. Can run setup-only (the slow scaffold + install) and be called again later to build on top.
---

# Prototype Studio

## Overview

Turn a non-technical business user's plain-language idea into a real, clickable web app they can show people. **They are not an engineer.** Keep the technical substrate invisible: they describe ideas, you make the machine cooperate and hand back something they can click and annotate.

Stack (all local, no accounts, no cloud, no Docker): **Next.js (TypeScript) + Drizzle ORM + SQLite**, with UI built from **shadcn/ui** (Tailwind v4 + semantic design tokens). Previewing uses the **integrated `Claude_Preview` tools** — never install or open a separate browser. The business user views the running app inline and **draws annotations on it** that come back to you.

The scaffolded repo carries its own copy of the **shadcn skill** at `.claude/skills/shadcn/` — so when the project is opened as its own workspace, future sessions pick it up automatically and build UI the shadcn way (search the registry → `add` components → compose). Use it; don't hand-roll markup or raw CSS.

This SOP runs in phases: **environment setup (Step 2)** is the slow, once-per-machine/project part (`npm install` + scaffold); **alignment (Step 3)** and **build (Step 4)** repeat for every idea and every revision. Step 1 sets up tracking and runs at the start of a session. Because setup is slow, the **`mode` parameter** lets you front-load it: run `mode: setup` once to get the environment ready and stop, then call the skill again with `mode: build` (the default) to build on top of it. `build` still verifies the environment first and will run setup itself if nothing is there — so a single `build` call also works end-to-end.

## Parameters

- **mode** (optional, default: "build"): Controls how far the workflow runs.
  - `setup` — run only the slow, one-time part: progress tracking (Step 1) + environment readiness and scaffold (Step 2), then **stop** and report how to resume. Use this to front-load the expensive `npm install` + scaffold so a later session can build immediately.
  - `build` — the full flow: **verify** the environment is ready (Step 2 — fast when setup already ran; if the scaffold or dependencies are missing, do the setup work first), then align (Step 3) and build (Step 4) on top of it.
- **app_idea** (optional): What the business user wants to prototype, at **any level of detail** — from a one-line plain-language idea ("a way to track customer feedback") to a full product brief with business rules, API endpoints, data shapes, and acceptance criteria. It MAY arrive as a chat message, a file path, pasted text, or a URL. Not needed for `mode: setup`. In `mode: build`, if not yet provided it is gathered conversationally during Step 3 rather than up front.
- **target_folder** (optional, default: a kebab-case folder named after the idea): Where the scaffolded app is created during Step 2.

**Constraints for parameter acquisition:**
- If all required parameters are already provided, You MUST proceed to the Steps.
- If any required parameters are missing, You MUST ask for them before proceeding.
- When asking for parameters, You MUST request all parameters in a single prompt.
- When asking for parameters, You MUST use the exact parameter names as defined.
- Because there are **no required parameters**, You MUST begin at Step 1 without prompting; both `app_idea` and `target_folder` are resolved naturally as the workflow proceeds.
- When `app_idea` is a file path, pasted document, or URL, You MUST read the full content (use the appropriate file/fetch tool) and treat it as a **product brief** — a richer input the alignment step parses rather than a one-line idea. See `reference/working-from-a-brief.md`.

## Steps

### 1. Set up progress tracking

Before doing anything else, create a visible plan so the business user and any future session can see where things stand.

**Constraints:**
- You MUST create a todo list at the very start of the session using the `TaskCreate` tool, scoped to the `mode`:
  - For `mode: setup`, the list covers only the one-time work: **environment readiness** and **scaffold the starter**, ending with **report how to resume** (`mode: build`).
  - For `mode: build` (default), the list covers the full arc: **verify environment readiness (set up if missing)**, **restate & align with the user**, **(optional) offer looks**, **build the prototype**, and **verify persistence through the preview**.
- When the input is a product brief (a file, paste, or URL rather than a one-line idea), You MUST also add a task to **extract the brief's rules, services, secrets, and acceptance criteria** (per `reference/working-from-a-brief.md`) and a task to **verify the build against those acceptance criteria** before reporting success.
- You MUST mark exactly one task `in_progress` as you begin it and `completed` as you finish it, using `TaskUpdate`, so progress is always legible.
- You MUST NOT skip a phase silently; if a phase does not apply (e.g. environment is already set up), You MUST mark its task complete and note why in one short line.
- You SHOULD add follow-up tasks when a revision or new idea arrives, rather than reusing stale ones.

### 2. Make sure the environment is ready (and scaffold a starter)

Do this silently and report only outcomes. You MUST NOT paste raw errors or ask the business user to run commands. This is the slow, once-per-machine/project part — so it MUST run **in both modes**, but it MUST be skipped when already done.

**Constraints:**
- **Check first; only do the missing work.** Before running anything heavy, probe setup state — but mind the bootstrap order: the status helper is itself a Node program, so You MUST confirm Node is present (substep 1) before relying on it. Once Node exists, You MUST run:
  ```
  node scripts/status.mjs <target-folder>
  ```
  It prints machine-readable JSON: `ok` (environment ready), a `missing` list (e.g. `nodeModules`, `claudeMd`, `sqliteDb`, `migrations`, `launchJson`), a `next` action (`install-node` / `scaffold` / `finish-setup` / `build`), and the current Node `lts` vs. the running version. On Windows you MUST read the `ok` field in the JSON, **not** the process exit code — some Node builds report exit 127 at teardown (a libuv assertion) despite correct output. If `ok` is true, You MUST treat Step 2 as done — mark its task complete, note that in one line, and (in `build` mode) proceed to Step 3 without re-installing. Otherwise You MUST do only the substeps that cover the `missing` items. If `node` itself is absent (the script can't run), the answer is simply "install Node first" — do substep 1, then re-probe.
- **Run the substeps below only for the parts that are missing**, **in order**. The doctor/scaffold scripts are idempotent, so re-running is safe, but You SHOULD avoid a needless `npm install` when deps are already present for this machine.
- **`mode: setup` stops after this step.** When `mode` is `setup`, after the environment is ready and verified through the preview (substep 5), You MUST stop — do not align or build. You MUST report that setup is complete and tell the business user how to resume, in this order:
  1. **Restart Claude (or run `/reload-skills`) before building.** You MUST instruct this explicitly, because setup registered the Exa MCP server and vendored the shadcn skill into the project — neither is picked up until skills/MCP reload at startup. Skipping this means the build session runs without research tools or the shadcn skill.
  2. **Open the project folder itself as the workspace** — the smoothest way to continue, so its own `.claude/launch.json` and vendored skill are found directly.
  3. **Re-invoke the skill with `mode: build`** to align and build on the ready environment.

  When `mode` is `build`, You MUST continue to Step 3.

You MUST perform the following substeps **in order** (for whatever is not already done):

1. **Check for Node first — with a plain shell command, not a script.** The `status.mjs`/`doctor.mjs` helpers are themselves Node programs, so they cannot run when Node is absent — the one case you most need to detect. You MUST therefore first check directly in the shell:
   ```
   node --version && npm --version
   ```
   - **If that fails (Node missing):** You MUST install Node from the official site and add it to the **permanent** PATH (so new terminals find it) before running any helper script — see `reference/install-node.md` for per-OS instructions (Windows, macOS, Linux), all of which work without an existing Node. You MUST determine the LTS version to install by querying `nodejs.org` at runtime (the commands in `reference/install-node.md` include Node-free lookups for macOS/Linux and Windows); You MUST NOT assume an LTS version from memory, as it advances over time and a recalled value is routinely stale.
   - **Immediately after installing, refresh PATH in the current session and re-verify — do not wait for a new shell.** The install only updates the *persistent* PATH (new shells), so the session you're in won't see Node yet. You MUST prepend the install dir to the session PATH and re-run the check before concluding anything: macOS/Linux `export PATH="$HOME/.local/node/bin:$PATH"`; Windows PowerShell `$env:Path = "$env:USERPROFILE\nodejs;$env:Path"`. You MUST NOT read a still-failing `node --version` as "install failed" and reinstall. If your command runner spawns a fresh process per call (so the session PATH doesn't carry across calls), invoke Node/npm by **full path** instead — `reference/install-node.md` gives the exact locations (`%USERPROFILE%\nodejs\node.exe`, `npm.cmd`).
   - **Once Node is present**, You MAY use `node scripts/doctor.mjs` (toolchain + current-LTS report) and `node scripts/status.mjs <target-folder>` (setup-state report) for richer detail — but these are conveniences that presuppose Node, never the Node-presence check itself.

   If `node_modules` exists in a project but fails, You MUST assume it was copied from another machine: delete it and reinstall cleanly for *this* OS. Native pieces (the SQLite driver) MUST be installed fresh here, never reused.

2. **Scaffold the starter app.** You MUST run, from the skill directory:
   ```
   node scripts/scaffold.mjs <target-folder>
   ```
   This copies `templates/starter/` (a minimal Next.js + Drizzle + SQLite app with a working, persistent "Items" list, already rendered with shadcn/ui), runs `npm install`, creates the SQLite file, applies the first migration, and seeds a few realistic example rows. The starter ships shadcn fully wired — `components.json`, Tailwind v4 tokens in `src/app/globals.css`, `cn()` in `src/lib/utils.ts`, base components (`button`, `card`, `input`, `label`) in `src/components/ui/`, and the vendored shadcn skill in `.claude/skills/shadcn/`. No `shadcn init` is needed; You MAY run `npx shadcn@latest add <name>` for more components later. The script is idempotent and prints what it did.

3. **Write `CLAUDE.md` into the project root.** You MUST copy `reference/CLAUDE.md.template` into the new project as `CLAUDE.md`, filling the `<…>` placeholders with the real values (Node version, database file path, run command + port). This file carries the working agreement and the self-healing rules into every future session in that folder — **it is how the prototype partner persists.** You MUST keep it updated (see "Keep CLAUDE.md current").

4. **Add the Exa MCP server (web search / research).** You MUST register Exa as a remote MCP server so future sessions have search/research tools — `reference/exa-mcp.md` has the exact steps (You SHOULD prefer `claude mcp add …`; otherwise merge an `mcpServers.exa` entry into `~/.claude.json` and re-validate the JSON). It only takes effect after a restart; You SHOULD confirm later with `/mcp`. If it is already configured, You MUST leave it as is. You MUST NOT treat this substep as optional — it is part of the one-time environment setup, not a nice-to-have.

5. **Prove it works through the preview.** You MUST start the app with the `Claude_Preview` tools (the starter ships a `.claude/launch.json` with `autoPort` on, so if port 3000 is taken the preview picks a free one automatically), screenshot to confirm it renders, then **test persistence end to end**: add an item via the UI, reload, confirm it survived. You MUST treat that last action — not "the server booted" — as the proof the database works.

   **The preview finds `launch.json` relative to the session's working directory.** When you scaffolded into a subfolder, the session cwd is the *parent*, so `preview_start` won't see the project's own `.claude/launch.json`. You MUST resolve this one of two ways:
   - **Preferred:** open the project folder itself as the workspace — then its `.claude/launch.json` is found directly. Tell the business user this is how they re-open it.
   - **Fallback (when you can't change the cwd, e.g. mid-session):** create a copy of `.claude/launch.json` at the session cwd that runs the dev server from the subfolder. This is a per-session shim, not the canonical config; the project's own `.claude/launch.json` stays the source of truth, and You SHOULD remove the shim when the project is later opened as its own workspace.
     - **macOS/Linux:** `runtimeExecutable: "npm"` with `runtimeArgs: ["--prefix", "<subfolder>", "run", "dev"]` (keep `autoPort: true`).
     - **Windows:** the `--prefix` form usually **fails** — the preview spawns the dev process without the shell's PATH, so even `npm.cmd` can't find `node`. You MUST instead launch through `cmd.exe` and set PATH + `cd` inline, using the **full Node install dir** (`%USERPROFILE%\nodejs`, see `reference/install-node.md`):
       ```json
       {
         "runtimeExecutable": "C:\\Windows\\System32\\cmd.exe",
         "runtimeArgs": ["/c", "set PATH=%USERPROFILE%\\nodejs;%PATH% && cd <subfolder> && npm run dev"],
         "autoPort": true
       }
       ```

For the full step-2 contract (install latitude, what to ask before, OS specifics), You SHOULD read `reference/environment.md`.

### 3. Align on the idea (adaptive grilling)

One flow handles every input, scaling to whatever detail it's given. A one-line idea has many gaps to fill; a detailed brief has few — mostly things to confirm. The goal is the same either way: **shared understanding** before you build, reached without ever making the business user feel interrogated or talked down to.

**Constraints:**
- **Investigate before asking.** If a question can be answered from what you already have, You MUST answer it yourself rather than asking: read the brief in full, probe any endpoints it names to learn the real data shapes, and check existing project files. You MUST only ask about things you genuinely cannot resolve. (When the input is a brief, follow `reference/working-from-a-brief.md` to extract rules, services, secrets, and acceptance criteria first.)
- **Restate to confirm you understood.** You MUST play back, in one or two plain sentences, what you're building and the key decisions you're making for them. For a brief, this restate MUST also surface the concrete rules you extracted (e.g. the scoring math, what a screen must show) so they can catch a misread.
- **Grill one question at a time.** When a gap genuinely needs the business user, You MUST ask **one question at a time**, not a batch — each answer can change what you ask next. You MUST pair every question with your **recommended answer** so they can just say "yes" ("I'm assuming X — sound right?"). You MUST keep questions in plain language about the product, never about technical implementation (you decide that yourself).
- **Scale the grilling to the gaps.** You SHOULD ask more for a sparse idea (it has real ambiguity) and fewer for a detailed brief (mostly confirm your reading and the one or two true ambiguities). You MUST NOT pad a well-specified brief with questions whose answers it already contains.
- **Stop when aligned.** Once the decisions that affect what you build are settled, You MUST stop asking and proceed — You MUST NOT grill for its own sake.
- You MAY offer two or three different looks for the main screen, described in plain language (not technical mockups), and let them pick. You MUST describe them the way you'd describe them to a colleague.

### 4. Build the prototype up from the starter

Build the idea as a real, clickable app **on top of the scaffolded starter** — reuse its Next.js screens, its Drizzle + SQLite setup, and its preview wiring rather than starting over.

**Constraints:**
- Anything the business user adds or changes MUST **actually persist**: add it → reload → it's still there. When data is involved, You MUST evolve the database with a Drizzle migration rather than faking it in memory.
- **Local SQLite for user-generated data; live calls for reference data.** When a brief names external services, You MUST keep what the user creates (predictions, picks, comments) in the local SQLite DB, and fetch reference data the brief owns (match lists, standings, membership) live from those services rather than copying it into the DB.
- **Wrap each external service in one server-side module.** You MUST put all external API calls behind a single server-side lib module (e.g. `src/lib/<domain>-api.ts`) called from server actions or server components — never fetched directly from client components. You MUST mind read-then-write endpoints: if an update endpoint *replaces* a value (e.g. a leaderboard `PUT` that overwrites a score), You MUST read the current value and add to it rather than overwriting.
- **Secrets stay server-side.** Any API key or token (from a brief or elsewhere) MUST be used only in server-side code, MUST be read from a gitignored env file (`.env.local`), and MUST NOT appear in client components, `NEXT_PUBLIC_*` vars, the browser bundle, or committed source. You MUST NOT hardcode a key into a component. See `reference/working-from-a-brief.md`.
- You MUST build the UI with shadcn/ui. The shadcn skill is vendored at `.claude/skills/shadcn/` — follow it: reach for existing components (`npx shadcn@latest search`, then `npx shadcn@latest add <name>`) and compose them rather than writing custom markup or raw CSS. You MUST use semantic tokens (`bg-primary`, `text-muted-foreground`) and component variants, not hardcoded colors. The starter's base components (`button`, `card`, `input`, `label`) are already installed; You MAY add more as the idea needs them.
- You MUST meet the quality bar: realistic, believable mock data (never lorem ipsum or "Item 1, Item 2") — when a brief exposes a live data source, You SHOULD ground mock/seed data in its real shapes; the important things work when clicked (tabs switch, items select, panels/drawers open and close); polished and modern — clean typography, restrained color, clear hierarchy.
- You MUST show it in the integrated preview and verify it works (including that saved data survives a reload) **before** reporting success, then tell them in plain English what they can click and what will happen — so they can trust it without reading code.
- **Verify against the brief's rules.** When the input was a brief, before reporting success You MUST check the build against the acceptance criteria you extracted in Step 1 (e.g. scoring math is correct, a profile total combines the right sources, an update actually persists to the external service), not just "it renders and saves."
- You SHOULD expect annotation-driven revisions. They'll often draw on the preview or ask in everyday language ("make this feel calmer," "the important ones should jump out more," "add a way to save a favorite"). When they annotate, You MUST treat the marks as pointing at what they mean. You MUST treat every request as normal and return an updated version each time.
- If a prototype takes off and they want engineers involved, You SHOULD offer a short plain-language handoff summary they can pass along.

## Keep CLAUDE.md current

`CLAUDE.md` is created in Step 2 and is a **living file** — You MUST update it as the project grows so a future cold session is never surprised:
- When you add a real data model/feature, note it under "What's set up here."
- If the run command, port, or database location changes, update it.
- If you install a new tool to make something work, record it (and where).

The goal: opening the project fresh, you can act correctly from `CLAUDE.md` alone.

## Keeping the environment working (all steps, silently)

Setup breaks in confusing ways. When a command fails for an environmental reason — missing tool, wrong-platform dependency, no package manager, locked file, missing native binary — You MUST fix it yourself and re-verify the original goal before reporting success. You MAY install developer tooling from official vendor sites without asking. You MUST still ask before: spending money, signing into/creating accounts, publishing or sending anything, changing security/system settings, or deleting files the business user created. You MUST report in outcomes, not mechanics. Full details: `reference/environment.md`.

## Examples

**Starting cold from an idea.** The business user says *"Add a page where I can track customer feedback with a title, a priority, and who owns it."* You create the todo list (Step 1), confirm the environment and scaffold if needed (Step 2), restate the idea in one sentence and decide the small details yourself (Step 3), then build the feedback tracker on the starter with a Drizzle table, shadcn table + form UI, and realistic seeded rows — verifying through the preview that a new entry survives a reload before handing it back (Step 4).

**Front-loading the slow setup.** The business user knows they'll want to prototype later and wants the slow part out of the way. You run with `mode: setup`: create a setup-scoped todo list (Step 1), get the environment ready and scaffold the starter (Step 2), verify it renders and persists through the preview, then **stop** — reporting that setup is done and telling them to **restart Claude (or `/reload-skills`)**, open the project folder as its own workspace, and re-invoke with `mode: build`. Later they return with an idea; a `mode: build` call finds the scaffold already in place, skips the install, and goes straight to aligning and building (Steps 3–4) in seconds rather than minutes.

**A revision via annotation.** They draw a circle around the priority badges and write "these should pop." You treat the marks as pointing at the priority column, increase its visual weight using shadcn `badge` variants and semantic tokens, re-verify in the preview, and report what changed in one plain sentence.

**Starting from a detailed brief.** The business user hands you a file path to a product brief with API endpoints, an exact scoring rule, a leaderboard `PUT` that replaces the score, and an API key in plaintext. You read it in full and extract its rules, services, secrets, and acceptance criteria (`reference/working-from-a-brief.md`); add todo tasks for that extraction and for verifying against the criteria (Step 1); probe the live endpoints to learn the real data shapes; restate the few genuine ambiguities one at a time with recommended answers (Step 3); then build — user picks in local SQLite, reference data fetched live through one server-side lib module, the API key in gitignored `.env.local` and never in the browser, and the leaderboard updated by reading-then-adding — verifying the scoring math and that an update persists before handing it back (Step 4).

## Troubleshooting

- **Preview won't start / can't find `launch.json`:** check `.claude/launch.json` first; if you scaffolded into a subfolder, apply the subfolder fix in Step 2.5. See `reference/environment.md`.
- **`node_modules` fails after being copied from another machine:** delete it and `npm install` fresh on this machine (native SQLite driver must be built here).
- **No Node/npm on PATH:** install Node per `reference/install-node.md` and persist PATH.
- **Exa tools not showing up:** MCP servers load at startup — restart and confirm with `/mcp`.
- **Input is a brief / has technical detail or an API key:** don't discard the detail or expose the key — follow `reference/working-from-a-brief.md` (extract rules and services, keep secrets server-side, verify against acceptance criteria).
- For the complete environment contract and OS-specific notes, read `reference/environment.md`.
