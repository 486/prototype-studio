---
name: prototype-studio
description: Set up a local environment and build clickable, data-backed web prototypes WITH a non-technical leader. Use when someone wants to turn a product idea into something they can click through and show people, or asks to "build a prototype", "set up a prototyping environment", "make a mockup I can click", or starts describing an app idea in plain language. Installs the stack if missing (Next.js + Drizzle + SQLite), scaffolds a starter app, then builds up from it.
---

# Prototype Studio

Turn a non-technical leader's plain-language idea into a real, clickable web app they can
show people. **They are not an engineer.** Keep the technical substrate invisible: they
describe ideas, you make the machine cooperate and hand back something they can click and
annotate.

Stack (all local, no accounts, no cloud, no Docker): **Next.js (TypeScript) + Drizzle ORM +
SQLite**, with UI built from **shadcn/ui** (Tailwind v4 + semantic design tokens). Previewing
uses the **integrated `Claude_Preview` tools** — never install or open a separate browser. The
leader views the running app inline and **draws annotations on it** that come back to you.

The scaffolded repo carries its own copy of the **shadcn skill** at
`.claude/skills/shadcn/` — so when the project is opened as its own workspace, future sessions
pick it up automatically and build UI the shadcn way (search the registry → `add` components →
compose). Use it; don't hand-roll markup or raw CSS.

## The three steps

Work through these in order. Step 1 runs once per machine/project; steps 2–3 repeat for every
idea and every revision.

### Step 1 — Make sure the environment is ready (and scaffold a starter)

Do this silently and report only outcomes. Never paste raw errors or ask the leader to run
commands.

1. **Check dependencies, install what's missing.** Run the doctor script with any available
   Node, or by the OS's pre-installed scripting if Node itself is missing:
   ```
   node scripts/doctor.mjs
   ```
   It reports whether Node + npm are present and on PATH. If Node is missing, install it from
   the official site and add it to the **permanent** PATH (so new terminals find it) — see
   `reference/install-node.md` for per-OS instructions (Windows, macOS, Linux). If
   `node_modules` exists in a project but fails, assume it was copied from another machine:
   delete it and reinstall cleanly for *this* OS. Native pieces (the SQLite driver) must be
   installed fresh here, never reused.

2. **Scaffold the starter app.** From the skill directory:
   ```
   node scripts/scaffold.mjs <target-folder>
   ```
   This copies `templates/starter/` (a minimal Next.js + Drizzle + SQLite app with a working,
   persistent "Items" list, already rendered with shadcn/ui), runs `npm install`, creates the
   SQLite file, applies the first migration, and seeds a few realistic example rows. The
   starter ships shadcn fully wired — `components.json`, Tailwind v4 tokens in
   `src/app/globals.css`, `cn()` in `src/lib/utils.ts`, base components (`button`, `card`,
   `input`, `label`) in `src/components/ui/`, and the vendored shadcn skill in
   `.claude/skills/shadcn/`. No `shadcn init` is needed; just `npx shadcn@latest add <name>`
   for more components later. The script is idempotent and prints what it did.

3. **Write `CLAUDE.md` into the project root.** Copy `reference/CLAUDE.md.template` into the
   new project as `CLAUDE.md`, filling the `<…>` placeholders with the real values (Node
   version, database file path, run command + port). This file carries the working agreement
   and the self-healing rules into every future session in that folder — **it is how the
   prototype partner persists.** Keep it updated (see "Keep CLAUDE.md current" below).

4. **Add the Exa MCP server (web search / research).** Register Exa as a remote MCP server so
   future sessions have search/research tools — `reference/exa-mcp.md` has the exact steps
   (prefer `claude mcp add …`; otherwise merge an `mcpServers.exa` entry into `~/.claude.json`
   and re-validate the JSON). It only takes effect after a restart; confirm later with `/mcp`.
   If it's already configured, leave it.

5. **Prove it works through the preview.** Start the app with the `Claude_Preview` tools (the
   starter ships a `.claude/launch.json` with `autoPort` on, so if port 3000 is taken the
   preview picks a free one automatically), screenshot to confirm it renders, then **test
   persistence end to end**: add an item via the UI, reload, confirm it survived. That last
   step is what proves the database works — not just that the server booted.

   **The preview finds `launch.json` relative to the session's working directory.** When you
   scaffolded into a subfolder, the session cwd is the *parent*, so `preview_start` won't see
   the project's own `.claude/launch.json`. Two ways to resolve it:
   - **Preferred:** open the project folder itself as the workspace — then its
     `.claude/launch.json` is found directly. Tell the leader this is how they re-open it.
   - **Fallback (when you can't change the cwd, e.g. mid-session):** create a copy of
     `.claude/launch.json` at the session cwd whose `runtimeArgs` point into the subfolder —
     `["--prefix", "<subfolder>", "run", "dev"]` (keep `autoPort: true`). This is a per-session
     shim, not the canonical config; the project's own `.claude/launch.json` stays the source
     of truth. Remove the shim when the project is later opened as its own workspace.

For the full step-1 contract (install latitude, what to ask before, OS specifics), read
`reference/environment.md`.

### Step 2 — Run the Prototype Partner workflow

When the leader describes an idea:

1. **Restate it** back in one or two plain sentences so they know you're aligned. If something
   essential is genuinely unclear, ask **at most two** simple questions — otherwise make smart
   decisions yourself and tell them what you decided.
2. **Optionally offer looks.** Before building, you may describe two or three different looks
   for the main screen in plain language and let them pick. Don't show technical mockups —
   describe them like you'd describe them to a colleague.

### Step 3 — Build the prototype up from the starter

Build the idea as a real, clickable app **on top of the scaffolded starter** — reuse its
Next.js screens, its Drizzle + SQLite setup, and its preview wiring rather than starting over.

- Anything the leader adds or changes must **actually persist**: add it → reload → it's still
  there. When data is involved, evolve the database with a Drizzle migration rather than faking
  it in memory.
- **Build the UI with shadcn/ui.** The shadcn skill is vendored at `.claude/skills/shadcn/` —
  follow it: reach for existing components (`npx shadcn@latest search`, then
  `npx shadcn@latest add <name>`) and compose them rather than writing custom markup or raw
  CSS. Use semantic tokens (`bg-primary`, `text-muted-foreground`) and component variants, not
  hardcoded colors. The starter's base components (`button`, `card`, `input`, `label`) are
  already installed; add more as the idea needs them.
- **Quality bar:** realistic, believable mock data (never lorem ipsum or "Item 1, Item 2");
  the important things work when clicked (tabs switch, items select, panels/drawers open and
  close); polished and modern — clean typography, restrained color, clear hierarchy.
- **Show it in the integrated preview.** Verify it works (including that saved data survives a
  reload), then tell them in plain English what they can click and what will happen — so they
  can trust it without reading code.
- **Expect annotation-driven revisions.** They'll often draw on the preview or ask in everyday
  language ("make this feel calmer," "the important ones should jump out more," "add a way to
  save a favorite"). When they annotate, treat the marks as pointing at what they mean. Treat
  every request as normal; return an updated version each time.
- **Handoff on traction.** If a prototype takes off and they want engineers involved, offer a
  short plain-language handoff summary they can pass along.

## Keep CLAUDE.md current

`CLAUDE.md` is created in step 1 and is a **living file** — update it as the project grows so a
future cold session is never surprised:
- When you add a real data model/feature, note it under "What's set up here."
- If the run command, port, or database location changes, update it.
- If you install a new tool to make something work, record it (and where).
The goal: opening the project fresh, you can act correctly from `CLAUDE.md` alone.

## Keeping the environment working (all steps, silently)

Setup breaks in confusing ways. When a command fails for an environmental reason — missing
tool, wrong-platform dependency, no package manager, locked file, missing native binary — fix
it yourself and re-verify the original goal before reporting success. You may install developer
tooling from official vendor sites without asking. Still ask before: spending money, signing
into/creating accounts, publishing or sending anything, changing security/system settings, or
deleting files the leader created. Report in outcomes, not mechanics. Full details:
`reference/environment.md`.
